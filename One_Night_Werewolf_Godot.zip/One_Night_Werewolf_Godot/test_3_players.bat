@echo off
setlocal
set "GODOT_EXE=%~1"
if not defined GODOT_EXE set "GODOT_EXE=godot"
"%GODOT_EXE%" --version >nul 2>&1
if errorlevel 1 (
 echo Drag the Godot 4.6 executable onto this BAT file.
 echo Or run: test_3_players.bat "C:\Path\Godot_v4.6.3-stable_win64.exe"
 pause
 exit /b 1
)
"%GODOT_EXE%" --headless --editor --path "%~dp0." --import --quit
start "Werewolf Host" "%GODOT_EXE%" --path "%~dp0." -- --host --name=Host
 timeout /t 2 /nobreak >nul
start "Werewolf Player 2" "%GODOT_EXE%" --path "%~dp0." -- --join=127.0.0.1 --name=Player2
start "Werewolf Player 3" "%GODOT_EXE%" --path "%~dp0." -- --join=127.0.0.1 --name=Player3
