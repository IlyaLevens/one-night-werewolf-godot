class_name ScoresView
extends VBoxContainer
var rows: Dictionary = {}
var signature = ""

func refresh(board: Dictionary) -> void:
	var next_signature = JSON.stringify(board)
	if signature == next_signature: return
	signature = next_signature
	var players: Array = board.players.duplicate(true)
	players.sort_custom(func(a,b): return a.score > b.score if a.score != b.score else a.name < b.name)
	var maximum = 1.0
	for p in players: maximum = maxf(maximum,p.score)
	for id in rows.keys():
		if not players.any(func(p): return p.id == id): rows[id].root.queue_free(); rows.erase(id)
	for index in range(players.size()):
		var p = players[index]
		if not rows.has(p.id):
			var root = VBoxContainer.new(); root.add_theme_constant_override("separation",5); add_child(root)
			var label = Label.new(); root.add_child(label)
			var bar = ProgressBar.new(); bar.custom_minimum_size = Vector2(0,20); bar.show_percentage = false; root.add_child(bar)
			rows[p.id] = {"root":root,"label":label,"bar":bar,"score":0.0,"tween":null}
		var row = rows[p.id]
		move_child(row.root,index)
		if row.tween: row.tween.kill()
		row.tween = create_tween().set_parallel(true)
		row.tween.tween_property(row.bar,"value",float(p.score)/maximum*100,0.8).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		row.tween.tween_method(func(value):
			row.score = value
			row.label.text = "%s    %s очк.   +%s" % [p.name,roundi(value),p.points],row.score,float(p.score),0.8)
