class_name GameRules
extends RefCounted

# This object exists only on the host. Clients receive view(id), never players.
var players: Dictionary = {}
var host: String = ""
var phase: String = "lobby"
var round_number: int = 0
var deck: Array = Roles.default_deck(3)
var custom_deck: bool = false
var settings: Dictionary = {"night_seconds":20, "discussion_seconds":180, "vote_seconds":45}
var center: Array = []
var original_center: Array = []
var night_steps: Array = []
var night_index: int = -1
var deadline: float = -1.0
var acted: Array = []
var history: Array = []
var chat: Array = []
var result: Dictionary = {}
var scored_round: int = -1
var music: Dictionary = {"file":"", "playing":false, "position":0.0, "changed_at":0.0, "revision":0}
var music_files: Array = []

func night_role() -> String:
	return str(night_steps[night_index]) if phase == "night" and night_index >= 0 and night_index < night_steps.size() else ""

func stage() -> String:
	return "%s:%s:%s" % [round_number, phase, night_role()]

func add_player(id: String, nickname: String) -> String:
	if phase != "lobby": return "Раунд уже начался. Дождитесь лобби."
	if players.size() >= 10: return "В лобби уже 10 игроков."
	var clean = nickname.strip_edges().replace("\n", " ").replace("\r", " ").replace("\t", " ")
	if clean.is_empty() or clean.length() > 24: return "Имя: от 1 до 24 символов."
	for p in players.values():
		if p.name.to_lower() == clean.to_lower(): return "Это имя уже занято."
	players[id] = {"id":id, "name":clean, "ready":false, "online":true, "original":"", "card":"", "notes":[], "vote":"", "score":0, "points":0, "chat_at":-100.0}
	if host.is_empty(): host = id
	roster_changed()
	return ""

func roster_changed() -> void:
	if not custom_deck: deck = Roles.default_deck(maxi(3, players.size()))
	for p in players.values(): p.ready = false

func validate_deck(cards: Array) -> String:
	if cards.size() != maxi(3, players.size()) + 3: return "Нужно ровно игроков + 3 карты центра."
	for role in cards:
		if not role is String or not Roles.DATA.has(role): return "Неизвестная роль."
		if cards.count(role) > Roles.DATA[role].limit: return "Превышен лимит: " + Roles.title(role)
	if cards.count("mason") not in [0, 2]: return "Масоны добавляются только парой."
	if not cards.has("werewolf"): return "Добавьте хотя бы одного оборотня."
	return ""

func command(id: String, action: String, data: Dictionary, now: float) -> String:
	if not players.has(id): return "Сессия не найдена."
	if str(data.get("stage", "")) != stage(): return "Фаза уже сменилась. Повторите действие."
	var p: Dictionary = players[id]
	if action in ["start", "reset", "settings", "begin_vote", "kick", "music"] and id != host:
		return "Это действие доступно создателю."
	match action:
		"ready":
			if phase not in ["lobby", "reveal"]: return "Сейчас нельзя подтвердить готовность."
			p.ready = not p.ready if phase == "lobby" else true
			if phase == "reveal" and players.values().all(func(x): return x.ready): begin_night(now)
		"start":
			if phase != "lobby": return "Раунд уже начался."
			if players.size() < 3: return "Нужно от 3 до 10 игроков."
			if not players.values().all(func(x): return x.ready and x.online): return "Все игроки должны быть в сети и готовы."
			var error = validate_deck(deck)
			if not error.is_empty(): return error
			var cards = deck.duplicate()
			cards.shuffle()
			for x in players.values():
				x.card = cards.pop_back()
				x.original = x.card
				x.notes = []
				x.vote = ""
				x.ready = false
			center = cards
			original_center = center.duplicate()
			history = []; acted = []; result = {}; chat = []
			round_number += 1
			phase = "reveal"; deadline = now + 90.0
			night_steps = Roles.ORDER.filter(func(r): return deck.has(r))
			night_index = -1
		"night_action":
			return night_action(id, data)
		"begin_vote":
			if phase != "discussion": return "Сейчас нет обсуждения."
			phase = "voting"; deadline = now + settings.vote_seconds
		"vote":
			if phase != "voting" or not p.vote.is_empty(): return "Сейчас нельзя голосовать повторно."
			var target = data.get("target", "")
			if not target is String or not players.has(target) or target == id: return "Выберите другого игрока."
			p.vote = target
			if players.values().all(func(x): return not x.vote.is_empty()): finish()
		"reset":
			phase = "lobby"; deadline = -1; result = {}
			center = []; original_center = []; history = []; acted = []; night_steps = []; night_index = -1
			for x in players.values():
				x.card = ""; x.original = ""; x.vote = ""; x.notes = []
			roster_changed()
		"settings":
			if phase != "lobby": return "Настройки доступны только в лобби."
			var next_settings = settings.duplicate()
			for key in settings:
				var value = data.get(key, settings[key])
				var limits = {"night_seconds":[10,60], "discussion_seconds":[30,900], "vote_seconds":[15,180]}[key]
				if not value is int or value < limits[0] or value > limits[1]: return "Недопустимый таймер: " + key
				next_settings[key] = value
			if not data.get("automatic", false) is bool: return "Некорректный режим колоды."
			var cards = Roles.default_deck(maxi(3,players.size())) if data.get("automatic",false) else data.get("deck",deck)
			if not cards is Array: return "Некорректная колода."
			var error = validate_deck(cards)
			if not error.is_empty(): return error
			settings = next_settings; deck = cards.duplicate(); custom_deck = not data.get("automatic",false)
			roster_changed()
		"chat":
			if phase not in ["lobby", "discussion", "results"]: return "Ночью и во время голосования чат закрыт."
			var message = data.get("message", "")
			if not message is String: return "Сообщение должно быть текстом."
			message = message.strip_edges()
			if message.is_empty() or message.length() > 500: return "Сообщение: от 1 до 500 символов."
			if now - p.chat_at < 0.7: return "Подождите секунду."
			p.chat_at = now
			chat.append({"name":p.name, "text":message})
			if chat.size() > 100: chat.pop_front()
		"kick", "leave":
			if phase not in ["lobby", "results"]: return "Дождитесь конца раунда или отмените его."
			var target = id if action == "leave" else data.get("target", "")
			if not target is String or not players.has(target) or target == host: return "Создатель может только закрыть сервер."
			players.erase(target); roster_changed()
		"music":
			var operation = data.get("operation", "")
			if operation == "select":
				var file = data.get("file", "")
				if not music_files.has(file): return "Трек отсутствует у сервера."
				music.file = file; music.position = 0.0
			elif operation in ["play", "pause"]:
				if music.file.is_empty(): return "Сначала выберите трек."
				music.position = music_position(now)
				music.playing = operation == "play"
			else: return "Неизвестная команда музыки."
			music.changed_at = now; music.revision += 1
		_:
			return "Неизвестное действие."
	return ""

func music_position(now: float) -> float:
	return music.position + (maxf(0, now - music.changed_at) if music.playing else 0.0)

func note(id: String, text: String, cards: Array = [], swap: Array = []) -> void:
	players[id].notes.append({"id":"%s:%s" % [round_number,players[id].notes.size()], "stage":stage(), "text":text, "cards":cards, "swap":swap})
	history.append({"name":players[id].name,"text":text})

func begin_night(now: float) -> void:
	phase = "night"; night_index = -1
	next_night(now)

func next_night(now: float) -> void:
	night_index += 1; acted = []
	if night_index >= night_steps.size():
		phase = "discussion"; deadline = now + settings.discussion_seconds
		return
	deadline = now + settings.night_seconds
	var role = night_role()
	var wolves = players.values().filter(func(p): return p.original == "werewolf")
	for p in players.values():
		if p.original != role: continue
		var peers: Array = []
		if role == "werewolf": peers = wolves.filter(func(x): return x.id != p.id)
		elif role == "minion": peers = wolves
		elif role == "mason": peers = players.values().filter(func(x): return x.original == "mason" and x.id != p.id)
		if role in ["werewolf", "minion", "mason"]:
			var text = "Найдены: " + ", ".join(peers.map(func(x): return x.name))
			if peers.is_empty(): text = "Другие начальные роли не найдены."
			if role == "werewolf" and peers.is_empty(): text = "Вы единственный проснувшийся оборотень. Можно посмотреть одну карту центра."
			var cards = peers.map(func(x): return {"key":"player:"+x.id,"role":x.original})
			note(p.id, text, cards)
		elif role == "insomniac":
			note(p.id, "В конце ночи ваша карта: " + Roles.title(p.card), [{"key":"player:"+p.id,"role":p.card}])

func available_action(id: String) -> String:
	var p: Dictionary = players[id]
	if phase != "night" or p.original != night_role() or acted.has(id): return ""
	if p.original == "werewolf":
		return "werewolf" if players.values().filter(func(x): return x.original == "werewolf").size() == 1 else ""
	return p.original if p.original in ["seer", "robber", "troublemaker", "drunk"] else ""

func night_action(id: String, data: Dictionary) -> String:
	var role = available_action(id)
	if role.is_empty(): return "Сейчас у вас нет ночного действия."
	var mode = data.get("mode", "")
	if mode == "skip":
		if role == "drunk": return "Пьяница обязан обменять карту."
		acted.append(id); note(id, "Вы пропустили действие.")
		return ""
	var targets = data.get("targets", [])
	var indexes = data.get("center", [])
	if not targets is Array or not indexes is Array or targets.size() > 2 or indexes.size() > 2: return "Некорректные цели."
	var unique: Array = []
	for target in targets:
		if not target is String or not players.has(target) or target == id or unique.has(target): return "Выберите разных других игроков."
		unique.append(target)
	unique = []
	for i in indexes:
		if not i is int or i < 0 or i > 2 or unique.has(i): return "Нужны разные карты центра."
		unique.append(i)
	var cards: Array = []
	var swap: Array = []
	var text = ""
	var p: Dictionary = players[id]
	match role:
		"werewolf":
			if mode != "center" or indexes.size() != 1 or not targets.is_empty(): return "Выберите одну карту центра."
			cards = [{"key":"center:%s" % indexes[0], "role":center[indexes[0]]}]
			text = "Центр %s: %s" % [indexes[0]+1, Roles.title(center[indexes[0]])]
		"seer":
			if mode == "player" and targets.size() == 1 and indexes.is_empty():
				cards = [{"key":"player:"+targets[0], "role":players[targets[0]].card}]
				text = "%s: %s" % [players[targets[0]].name, Roles.title(players[targets[0]].card)]
			elif mode == "center" and indexes.size() == 2 and targets.is_empty():
				for i in indexes:
					cards.append({"key":"center:%s" % i, "role":center[i]})
					text += "Центр %s: %s. " % [i+1,Roles.title(center[i])]
			else: return "Выберите одного игрока или две карты центра."
		"robber":
			if mode != "player" or targets.size() != 1 or not indexes.is_empty(): return "Выберите другого игрока."
			var other: Dictionary = players[targets[0]]
			var old = p.card; p.card = other.card; other.card = old
			cards = [{"key":"player:"+id,"role":p.card}]
			swap = ["player:"+id,"player:"+other.id]
			text = "Обмен с %s. Полученная карта: %s. Позже её ещё могут поменять." % [other.name,Roles.title(p.card)]
		"troublemaker":
			if mode != "players" or targets.size() != 2 or not indexes.is_empty(): return "Выберите двух других игроков."
			var a: Dictionary = players[targets[0]]; var b: Dictionary = players[targets[1]]
			var old = a.card; a.card = b.card; b.card = old
			swap = ["player:"+a.id,"player:"+b.id]
			text = "Вы поменяли карты %s и %s. Роли не раскрыты." % [a.name,b.name]
		"drunk":
			if mode != "center" or indexes.size() != 1 or not targets.is_empty(): return "Выберите одну карту центра."
			var i: int = indexes[0]; var old = p.card; p.card = center[i]; center[i] = old
			swap = ["player:"+id,"center:%s" % i]
			text = "Обмен с центром %s. Новая роль неизвестна." % (i+1)
	acted.append(id); note(id,text,cards,swap)
	return ""

func tick(now: float) -> void:
	while deadline >= 0 and now >= deadline:
		var boundary = deadline
		match phase:
			"reveal": begin_night(boundary)
			"night":
				for p in players.values():
					if available_action(p.id) == "drunk":
						night_action(p.id, {"mode":"center","center":[randi_range(0,2)]})
						note(p.id,"Время истекло: сервер выполнил обязательный обмен.")
					elif not available_action(p.id).is_empty(): note(p.id,"Время истекло: действие пропущено.")
				next_night(boundary)
			"discussion": phase = "voting"; deadline = boundary + settings.vote_seconds
			"voting": finish()
			_: deadline = -1

static func resolve(players_data: Dictionary) -> Dictionary:
	var counts: Dictionary = {}; var maximum: int = 0
	for p in players_data.values():
		if not str(p.vote).is_empty(): counts[p.vote] = counts.get(p.vote,0) + 1
	for count in counts.values(): maximum = maxi(maximum,count)
	var executed: Array = []
	for id in counts:
		if counts[id] == maximum and maximum >= 2: executed.append(id)
	var dead = executed.duplicate(); var hunter_victims: Array = []
	for id in executed:
		var p = players_data[id]
		if p.card == "hunter" and not str(p.vote).is_empty():
			if not dead.has(p.vote): dead.append(p.vote)
			hunter_victims.append(p.vote)
	var wolves = players_data.values().filter(func(x): return x.card == "werewolf")
	var minions = players_data.values().filter(func(x): return x.card == "minion")
	var wolf_dead = wolves.any(func(x): return dead.has(x.id))
	var minion_dead = minions.any(func(x): return dead.has(x.id))
	var tanner_won = players_data.values().any(func(x): return x.card == "tanner" and dead.has(x.id))
	var village_won = wolf_dead or (wolves.is_empty() and (dead.is_empty() or minion_dead))
	if tanner_won and not wolf_dead: village_won = false
	var wolves_won = ((not wolves.is_empty() and not wolf_dead) or (wolves.is_empty() and not minions.is_empty() and not minion_dead and not dead.is_empty())) and not tanner_won
	var teams: Array = []; var outcomes: Array = []; var reasons: Array = []
	if village_won: teams.append("village"); reasons.append("Деревня выполнила условие победы.")
	if wolves_won: teams.append("wolves"); reasons.append("Команда оборотней выполнила условие победы.")
	if tanner_won: teams.append("tanner"); reasons.append("Кожевник погиб и победил.")
	if teams.is_empty(): reasons.append("Оборотней у игроков нет, но погиб мирный. Никто не победил.")
	if maximum < 2: reasons.append("Никто не получил двух голосов: казни нет.")
	for p in players_data.values():
		outcomes.append({"id":p.id,"name":p.name,"original":p.original,"role":p.card,"vote":p.vote,"votes":counts.get(p.id,0),"dead":dead.has(p.id),"executed":executed.has(p.id),"hunter_victim":hunter_victims.has(p.id),"won":teams.has(Roles.DATA[p.card].team)})
	return {"teams":teams,"reasons":reasons,"players":outcomes}

func finish() -> void:
	if scored_round == round_number: return
	result = resolve(players)
	for outcome in result.players:
		var p: Dictionary = players[outcome.id]
		p.points = {"village":1,"wolves":2,"tanner":3}[Roles.DATA[outcome.role].team] if outcome.won else 0
		p.score += p.points
		outcome.points = p.points; outcome.score = p.score
	result.center = center.duplicate(); result.original_center = original_center.duplicate(); result.history = history.duplicate(true)
	scored_round = round_number; phase = "results"; deadline = -1

func view(id: String, now: float) -> Dictionary:
	var roster: Array = []; var scores: Array = []
	for p in players.values():
		roster.append({"id":p.id,"name":p.name,"ready":p.ready,"online":p.online,"host":p.id == host})
		scores.append({"id":p.id,"name":p.name,"score":p.score,"points":p.points})
	var p: Dictionary = players[id]
	var music_view = music.duplicate(); music_view.position = music_position(now); music_view.erase("changed_at")
	return {"phase":phase,"round":round_number,"stage":stage(),"host":host,"remaining":maxf(0,deadline-now) if deadline >= 0 else -1.0,
		"players":roster,"settings":settings.duplicate(),"deck":deck.duplicate(),"custom_deck":custom_deck,"night_role":night_role(),"night_steps":night_steps.duplicate(),
		"chat":chat.duplicate(true),"scoreboard":{"round":maxi(0,scored_round),"players":scores},"music":music_view,"music_files":music_files.duplicate(),
		"voted_count":players.values().filter(func(x): return not x.vote.is_empty()).size(),
		"me":{"id":id,"name":p.name,"original":p.original,"notes":p.notes.duplicate(true),"ready":p.ready,"vote":p.vote,"action":available_action(id),"action_done":acted.has(id)},
		"result":result.duplicate(true) if phase == "results" else {}}
