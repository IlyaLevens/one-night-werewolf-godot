extends Control
var view: Dictionary = {}
var content: VBoxContainer
var stage_box: VBoxContainer
var board: HFlowContainer
var notes: Label
var chat_log: Label
var chat_input: LineEdit
var timer: Label
var atmosphere: Atmosphere
var scores: ScoresView
var score_popup: Window
var popup_scores: ScoresView
var message: AcceptDialog
var confirmation: ConfirmationDialog
var turn: PanelContainer
var turn_label: Label
var cards: Dictionary = {}
var selection: Array = []
var last_stage = ""
var panel_signature = ""
var roster_signature = ""
var audio: GameAudio
var entry: VBoxContainer
var name_input: LineEdit
var address: LineEdit
var port: SpinBox
var key_input: LineEdit
var pending: Callable

func label(parent: Node, text: String, size: int = 18) -> Label:
	var node = Label.new(); node.text = text; node.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	node.add_theme_font_size_override("font_size",size); parent.add_child(node); return node

func button(parent: Node, text: String, callback: Callable) -> Button:
	var node = Button.new(); node.text = text; node.custom_minimum_size.y = 40
	node.pressed.connect(callback); parent.add_child(node); return node

func clear(parent: Node) -> void:
	for child in parent.get_children(): parent.remove_child(child); child.queue_free()

func _ready() -> void:
	var theme_base = Theme.new(); theme_base.default_font = load("res://assets/fonts/DejaVuSans.ttf"); theme_base.default_font_size = 17
	for kind in ["Button","LineEdit","SpinBox","ProgressBar","PanelContainer"]:
		for state in ["normal","panel","background","hover","pressed","focus"]:
			var style = StyleBoxFlat.new(); style.bg_color = Color("283347") if state != "hover" else Color("41516a")
			style.set_corner_radius_all(8); style.content_margin_left = 12; style.content_margin_right = 12; style.content_margin_top = 8; style.content_margin_bottom = 8
			theme_base.set_stylebox(state,kind,style)
	var fill = StyleBoxFlat.new(); fill.bg_color = Color("d8af63"); fill.set_corner_radius_all(7); theme_base.set_stylebox("fill","ProgressBar",fill)
	theme = theme_base
	var background = ColorRect.new(); background.color = Color("111827"); background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(background)
	var scroll = ScrollContainer.new(); scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(scroll)
	var margin = MarginContainer.new(); margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_"+side,24)
	scroll.add_child(margin); content = VBoxContainer.new(); content.add_theme_constant_override("separation",14); margin.add_child(content)
	label(content,"ONE NIGHT  /  ОДНА НОЧЬ",30)
	atmosphere = Atmosphere.new(); content.add_child(atmosphere)
	entry = VBoxContainer.new(); content.add_child(entry)
	label(entry,"От 3 до 10 игроков • один создаёт лобби, остальные подключаются")
	name_input = LineEdit.new(); name_input.placeholder_text = "Ваше имя"; name_input.text = "Игрок"; entry.add_child(name_input)
	address = LineEdit.new(); address.text = "127.0.0.1"; address.placeholder_text = "IP создателя"; entry.add_child(address)
	port = SpinBox.new(); port.min_value = 1024; port.max_value = 65535; port.value = 27888; entry.add_child(port)
	key_input = LineEdit.new(); key_input.placeholder_text = "Ключ восстановления (только для повторного входа)"; key_input.secret = true; entry.add_child(key_input)
	button(entry,"Создать лобби",func(): Net.host_game(name_input.text,int(port.value)))
	button(entry,"Подключиться",func(): Net.join_game(name_input.text,address.text,int(port.value),key_input.text))
	var toolbar = HFlowContainer.new(); content.add_child(toolbar)
	button(toolbar,"Таблица очков",func(): if not view.is_empty(): score_popup.popup_centered(Vector2i(650,480)))
	button(toolbar,"Правила ролей",show_rules)
	button(toolbar,"Ключ восстановления",func():
		if Net.active:
			DisplayServer.clipboard_set(Net.recovery_token); show_message("Ключ скопирован. Сохраните его для повторного входа:\n"+Net.recovery_token))
	button(toolbar,"Звук / музыка",show_audio)
	button(toolbar,"Выйти",func(): ask("Отключиться? Если вы создатель, сервер закроется для всех.",func(): Net.close(); reset_ui()))
	var motion = CheckButton.new(); motion.text = "Анимация окружения"; motion.button_pressed = true; toolbar.add_child(motion); motion.toggled.connect(func(on): atmosphere.motion = on)
	timer = label(content,"")
	stage_box = VBoxContainer.new(); content.add_child(stage_box)
	board = HFlowContainer.new(); board.add_theme_constant_override("h_separation",12); board.add_theme_constant_override("v_separation",12); content.add_child(board)
	notes = label(content,""); scores = ScoresView.new(); content.add_child(scores)
	chat_log = label(content,""); chat_input = LineEdit.new(); chat_input.placeholder_text = "Сообщение в общий чат (Enter)"; chat_input.max_length = 500; content.add_child(chat_input)
	chat_input.text_submitted.connect(func(text): Net.send("chat",{"message":text}); chat_input.clear())
	message = AcceptDialog.new(); message.title = "Одна ночь"; add_child(message)
	confirmation = ConfirmationDialog.new(); confirmation.title = "Подтверждение"; add_child(confirmation); confirmation.confirmed.connect(func(): if pending.is_valid(): pending.call())
	score_popup = Window.new(); score_popup.title = "Очки за все раунды"; score_popup.close_requested.connect(func(): score_popup.hide()); add_child(score_popup)
	var score_scroll = ScrollContainer.new(); score_scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); score_popup.add_child(score_scroll)
	popup_scores = ScoresView.new(); popup_scores.size_flags_horizontal = Control.SIZE_EXPAND_FILL; score_scroll.add_child(popup_scores)
	turn = PanelContainer.new(); turn.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(turn)
	var center = CenterContainer.new(); turn.add_child(center); var box = VBoxContainer.new(); box.custom_minimum_size.x = 650; center.add_child(box)
	turn_label = label(box,"",36); turn_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	button(box,"Понятно — перейти к столу",func(): turn.hide()); turn.hide()
	audio = GameAudio.new(); add_child(audio)
	Net.snapshot_changed.connect(refresh); Net.error_received.connect(show_message)
	Net.session_closed.connect(func(text): reset_ui(); show_message(text))
	Net.joined.connect(func(_id,token): key_input.text = token)
	reset_ui()
	var args: Dictionary = {}
	for arg in OS.get_cmdline_user_args():
		var parts = arg.trim_prefix("--").split("=",true,1); args[parts[0]] = parts[1] if parts.size()>1 else "true"
	if args.has("name"): name_input.text = args.name
	if args.has("port"): port.value = int(args.port)
	if args.has("test-bot"): var bot = load("res://tests/bot.gd").new(); add_child(bot)
	if args.has("host"): Net.host_game(name_input.text,int(port.value))
	elif args.has("join"): address.text = args.join; Net.join_game(name_input.text,address.text,int(port.value))
	if args.has("capture"):
		await get_tree().create_timer(3).timeout
		get_viewport().get_texture().get_image().save_png(args.capture)

func reset_ui() -> void:
	if audio:
		audio.music_player.stop(); audio.cue_player.stop(); audio.last_stage = ""; audio.current_file = ""; audio.music_player.stream = null
	view = {}; entry.show(); clear(stage_box); clear(board); cards.clear(); last_stage = ""; panel_signature = ""; roster_signature = ""
	notes.text = ""; timer.text = ""; chat_log.text = ""; scores.hide(); chat_input.hide(); turn.hide(); atmosphere.change("lobby")

func show_message(text: String) -> void:
	message.dialog_text = text; message.popup_centered(Vector2i(650,200))

func ask(text: String, callback: Callable) -> void:
	pending = callback; confirmation.dialog_text = text; confirmation.popup_centered(Vector2i(620,200))

func _process(_delta: float) -> void:
	if view.is_empty(): return
	var left = Net.remaining()
	timer.text = "Раунд %s  •  %s%s  •  %s" % [view.round,Roles.PHASES.get(view.phase,view.phase)," / "+Roles.title(view.night_role) if view.phase == "night" else "",("%s сек." % ceili(left)) if left >= 0 else Net.endpoint]

func refresh(next: Dictionary) -> void:
	view = next; entry.hide(); audio.update(view)
	if view.stage != last_stage:
		last_stage = view.stage; selection.clear(); confirmation.hide(); turn.hide(); atmosphere.change(view.phase)
		if view.phase == "reveal" or view.phase == "voting" or (view.phase == "night" and view.me.original == view.night_role):
			turn_label.text = "ВАША КАРТА ГОТОВА" if view.phase == "reveal" else ("ВРЕМЯ ГОЛОСОВАТЬ" if view.phase == "voting" else "ВАШ ХОД\n"+Roles.title(view.night_role))
			turn.show()
	var roster = JSON.stringify(view.players.map(func(p): return {"id":p.id,"name":p.name}))
	if roster != roster_signature:
		roster_signature = roster; clear(board); cards.clear()
		for i in range(3): make_card("center:%s"%i,"Центр %s"%(i+1))
		for p in view.players: make_card("player:"+p.id,p.name + (" • вы" if p.id == view.me.id else ""))
	for key in cards:
		var card: RoleCard = cards[key]; var face = ""; card.dead = false
		if key == "player:"+view.me.id: face = view.me.original
		if view.phase == "results":
			if key.begins_with("center:"): face = view.result.center[int(key.get_slice(":",1))]
			else:
				for p in view.result.players:
					if key == "player:"+p.id: face = p.role; card.dead = p.dead
		card.set_face(face); card.selected = selection.has(key); card.selection_number = selection.find(key)+1; card.queue_redraw()
	var sig = JSON.stringify([view.stage,view.me.ready,view.me.action_done,view.me.vote,view.players,view.deck])
	if sig != panel_signature: panel_signature = sig; build_panel()
	var lines: Array = []
	if not view.me.original.is_empty(): lines.append("Ваша начальная роль: "+Roles.title(view.me.original)+". Ночью карта могла измениться.")
	for note in view.me.notes: lines.append("• "+note.text)
	notes.text = "\n".join(lines)
	scores.visible = view.phase in ["lobby","results"]; scores.refresh(view.scoreboard); popup_scores.refresh(view.scoreboard)
	chat_input.visible = view.phase in ["lobby","discussion","results"]
	chat_log.text = "\n".join(view.chat.map(func(m): return m.name+": "+m.text))

func make_card(key: String, title: String) -> void:
	var box = VBoxContainer.new(); board.add_child(box); box.custom_minimum_size.x = 145
	var title_label = label(box,title,14); title_label.custom_minimum_size.x = 145
	var card = RoleCard.new(); card.card_key = key; box.add_child(card); cards[key] = card; card.pressed.connect(func(): choose(key))

func choose(key: String) -> void:
	if view.phase == "voting" and view.me.vote.is_empty():
		if not key.begins_with("player:") or key == "player:"+view.me.id: return
		selection = [key]
	elif view.phase == "night" and not view.me.action.is_empty():
		var role = view.me.action; var is_center = key.begins_with("center:")
		if key == "player:"+view.me.id: return
		if role in ["drunk","werewolf"] and not is_center: return
		if role in ["robber","troublemaker"] and is_center: return
		if selection.has(key): selection.erase(key)
		else:
			if not selection.is_empty() and selection[0].begins_with("center:") != is_center: selection.clear()
			var limit = 2 if role == "troublemaker" or (role == "seer" and is_center) else 1
			if selection.size() >= limit: selection.clear()
			selection.append(key)
	else: return
	refresh(view)

func build_panel() -> void:
	clear(stage_box)
	var host = view.host == view.me.id
	match view.phase:
		"lobby":
			label(stage_box,"Лобби • " + ", ".join(view.players.map(func(p): return p.name + (" ✓" if p.ready else " …") + (" (нет связи)" if not p.online else ""))))
			label(stage_box,"Колода: "+", ".join(view.deck.map(func(r): return Roles.title(r))),14)
			button(stage_box,"Отменить готовность" if view.me.ready else "Я готов",func(): Net.send("ready"))
			if host:
				button(stage_box,"Начать раунд",func(): Net.send("start")); button(stage_box,"Настроить колоду и таймеры",show_settings)
				for p in view.players:
					if p.id != view.me.id and not p.online: button(stage_box,"Удалить отключённого: "+p.name,func(): Net.send("kick",{"target":p.id}))
		"reveal":
			label(stage_box,"Запомните свою карту и подтвердите готовность.")
			if not view.me.ready: button(stage_box,"Запомнил, готов к ночи",func(): Net.send("ready"))
		"night":
			label(stage_box,"Просыпается: "+Roles.title(view.night_role))
			if not view.me.action.is_empty():
				label(stage_box,{"seer":"Выберите одного другого игрока или две карты центра.","werewolf":"Выберите одну карту центра.","robber":"Выберите другого игрока для обмена.","troublemaker":"Выберите двух других игроков для слепого обмена.","drunk":"Выберите карту центра для обязательного слепого обмена."}[view.me.action])
				button(stage_box,"Подтвердить выбранные карты",submit_action)
				if view.me.action != "drunk": button(stage_box,"Пропустить действие",func(): ask("Пропустить ночное действие?",func(): Net.send("night_action",{"mode":"skip"})))
			else: label(stage_box,"Прочитайте личные сведения ниже. Дождитесь окончания таймера.")
		"discussion":
			label(stage_box,"Обсудите, у кого сейчас оборотень. Используйте общий чат или голосовую связь.")
			if host: button(stage_box,"Перейти к голосованию",func(): ask("Закончить обсуждение?",func(): Net.send("begin_vote")))
		"voting":
			label(stage_box,"Выберите карточку другого игрока. Голос нельзя изменить.")
			if view.me.vote.is_empty(): button(stage_box,"Отдать голос",submit_action)
			else: label(stage_box,"Ваш голос принят. Ожидаем остальных.")
		"results":
			label(stage_box,"Победители: "+", ".join(view.result.teams.map(func(t): return Roles.TEAMS[t])),26)
			label(stage_box,"\n".join(view.result.reasons))
			for p in view.result.players:
				label(stage_box,"%s: %s → %s • голосов %s • +%s%s" % [p.name,Roles.title(p.original),Roles.title(p.role),p.votes,p.points," • убит охотником" if p.hunter_victim else (" • казнён" if p.executed else "")],15)
			button(stage_box,"История ночи",func(): show_message("\n".join(view.result.history.map(func(n): return n.name+": "+n.text))))
			if host: button(stage_box,"Следующий раунд (очки сохранятся)",func(): Net.send("reset"))
	if host and view.phase in ["reveal","night","discussion","voting"]: button(stage_box,"Отменить раунд",func(): ask("Вернуться в лобби без начисления очков за этот раунд?",func(): Net.send("reset")))

func submit_action() -> void:
	if selection.is_empty(): show_message("Сначала выберите карточки."); return
	var targets: Array = []; var indexes: Array = []
	for key in selection:
		if key.begins_with("center:"): indexes.append(int(key.get_slice(":",1)))
		else: targets.append(key.get_slice(":",1))
	var captured_stage = view.stage
	if view.phase == "voting":
		var target = targets[0]
		ask("Отдать голос за выбранного игрока?",func(): if view.stage == captured_stage: Net.send("vote",{"target":target}))
	else:
		var mode = "center" if not indexes.is_empty() else ("players" if view.me.action == "troublemaker" else "player")
		ask("Выполнить действие с выбранными картами?",func(): if view.stage == captured_stage: Net.send("night_action",{"mode":mode,"targets":targets,"center":indexes}))

func show_rules() -> void:
	var lines: Array = ["Ночью действуют начальные роли, победа определяется по итоговым картам. При максимуме менее двух голосов никто не казнён; при ничьей казнены все лидеры. Казнённый охотник забирает того, за кого проголосовал.","Очки: мирные +1, оборотни и миньон +2, кожевник +3. Очки выдаются каждому победившему игроку по итоговой команде."]
	for role in Roles.DATA: lines.append(Roles.title(role)+": "+str(Roles.DATA[role].get("description",Roles.DATA[role].get("ability",""))))
	var dialog = AcceptDialog.new(); dialog.title = "Правила"; add_child(dialog)
	var scroll = ScrollContainer.new(); scroll.custom_minimum_size = Vector2(700,440); dialog.add_child(scroll)
	var text = Label.new(); text.text = "\n\n".join(lines); text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; text.custom_minimum_size.x = 660; text.size_flags_horizontal = Control.SIZE_EXPAND_FILL; scroll.add_child(text)
	dialog.confirmed.connect(dialog.queue_free); dialog.canceled.connect(dialog.queue_free); dialog.popup_centered(Vector2i(740,520))

func show_settings() -> void:
	var dialog = ConfirmationDialog.new(); dialog.title = "Колода: число игроков + 3"; add_child(dialog)
	var box = VBoxContainer.new(); dialog.add_child(box)
	var values: Dictionary = {}; var counts: Dictionary = {}
	for key in view.settings:
		var row = HBoxContainer.new(); box.add_child(row); label(row,{"night_seconds":"Ночь, сек.","discussion_seconds":"Обсуждение, сек.","vote_seconds":"Голосование, сек."}[key])
		var spin = SpinBox.new(); spin.min_value = {"night_seconds":10,"discussion_seconds":30,"vote_seconds":15}[key]; spin.max_value = {"night_seconds":60,"discussion_seconds":900,"vote_seconds":180}[key]; spin.value = view.settings[key]; row.add_child(spin); values[key] = spin
	var auto = CheckButton.new(); auto.text = "Автоматическая колода"; auto.button_pressed = not view.custom_deck; box.add_child(auto)
	var grid = GridContainer.new(); grid.columns = 4; box.add_child(grid)
	for role in Roles.DATA:
		label(grid,Roles.title(role),14); var spin = SpinBox.new(); spin.max_value = Roles.DATA[role].limit; spin.value = view.deck.count(role); grid.add_child(spin); counts[role] = spin
	dialog.confirmed.connect(func():
		var data: Dictionary = {"automatic":auto.button_pressed,"deck":[]}
		for key in values: data[key] = int(values[key].value)
		for role in counts:
			for i in range(int(counts[role].value)): data.deck.append(role)
		Net.send("settings",data); dialog.queue_free())
	dialog.canceled.connect(dialog.queue_free); dialog.popup_centered(Vector2i(780,560))

func show_audio() -> void:
	var dialog = AcceptDialog.new(); dialog.title = "Звук"; add_child(dialog); var box = VBoxContainer.new(); dialog.add_child(box)
	label(box,"Громкость музыки / сигналов ролей (только у вас)")
	for kind in ["music_volume","cue_volume"]:
		var slider = HSlider.new(); slider.min_value = 0; slider.max_value = 1; slider.step = 0.05; slider.value = audio.get(kind); box.add_child(slider); slider.value_changed.connect(func(value): audio.set(kind,value))
	if not view.is_empty() and view.host == view.me.id:
		for file in view.music_files: button(box,file,func(): Net.send("music",{"operation":"select","file":file}))
		button(box,"Воспроизвести у всех",func(): Net.send("music",{"operation":"play"})); button(box,"Пауза у всех",func(): Net.send("music",{"operation":"pause"}))
	label(box,"Файлы музыки и сигналов нужно добавить в audio/ на всех компьютерах. Сигнал ночной роли слышат все.",14)
	dialog.confirmed.connect(dialog.queue_free); dialog.canceled.connect(dialog.queue_free); dialog.popup_centered(Vector2i(650,400))
