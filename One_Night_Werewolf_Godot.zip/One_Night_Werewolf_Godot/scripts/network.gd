extends Node

signal snapshot_changed(view: Dictionary)
signal error_received(message: String)
signal session_closed(message: String)
signal joined(id: String, token: String)

const PROTOCOL = 1
const DEFAULT_PORT = 27888
var rules: GameRules
var snapshot: Dictionary = {}
var session_id = ""
var recovery_token = ""
var endpoint = ""
var peer_sessions: Dictionary = {}
var tokens: Dictionary = {}
var requests_at: Dictionary = {}
var joining_name = ""
var joining_token = ""
var active = false
var elapsed = 0.0
var clock_received = 0.0
var serial = 0
var latest_serial = -1
var connecting_since = -1.0

func _ready() -> void:
	multiplayer.connected_to_server.connect(_connected)
	multiplayer.connection_failed.connect(func(): _lost("Не удалось подключиться. Проверьте IP, порт и брандмауэр."))
	multiplayer.server_disconnected.connect(func(): _lost("Создатель закрыл сервер или связь потеряна. Можно восстановить вход по ключу."))
	multiplayer.peer_disconnected.connect(_disconnected)
	multiplayer.allow_object_decoding = false

func now() -> float:
	return Time.get_ticks_msec() / 1000.0

func host_game(nickname: String, port: int) -> void:
	close()
	var peer = ENetMultiplayerPeer.new()
	var error = peer.create_server(port, 16)
	if error != OK:
		error_received.emit("Не удалось открыть UDP-порт %s. Возможно, он уже занят." % port)
		return
	multiplayer.multiplayer_peer = peer
	rules = GameRules.new()
	var id = _secret().substr(0,16)
	error_received_if_any(rules.add_player(id,nickname))
	if rules.players.is_empty(): close(); return
	session_id = id; recovery_token = _secret(); tokens[recovery_token] = id; peer_sessions[1] = id
	rules.music_files = audio_files("res://audio/music/")
	active = true; endpoint = "Сервер • UDP %s" % port
	joined.emit(id,recovery_token)
	broadcast()

func join_game(nickname: String, address: String, port: int, token: String = "") -> void:
	close()
	var peer = ENetMultiplayerPeer.new()
	var error = peer.create_client(address.strip_edges(),port)
	if error != OK: error_received.emit("Не удалось создать подключение: " + error_string(error)); return
	joining_name = nickname; joining_token = token.strip_edges()
	endpoint = "%s:%s" % [address,port]
	multiplayer.multiplayer_peer = peer
	connecting_since = now()

func close() -> void:
	active = false; connecting_since = -1
	if multiplayer.multiplayer_peer: multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	rules = null; peer_sessions.clear(); tokens.clear(); requests_at.clear()
	snapshot = {}; session_id = ""; recovery_token = ""; latest_serial = -1; serial = 0

func _secret() -> String:
	return Crypto.new().generate_random_bytes(24).hex_encode()

func _connected() -> void:
	register_player.rpc_id(1,PROTOCOL,joining_name,joining_token)

@rpc("any_peer", "call_remote", "reliable")
func register_player(version: int, nickname: String, token: String) -> void:
	if not multiplayer.is_server() or rules == null: return
	var peer = multiplayer.get_remote_sender_id()
	if peer_sessions.has(peer): return
	if version != PROTOCOL: reject_join.rpc_id(peer,"Разные версии игры."); return
	if nickname.length() > 100 or token.length() > 128: reject_join.rpc_id(peer,"Некорректные данные входа."); return
	var id = ""
	if not token.is_empty():
		id = tokens.get(token,"")
		if id.is_empty() or not rules.players.has(id): reject_join.rpc_id(peer,"Неверный ключ восстановления."); return
		if rules.players[id].online: reject_join.rpc_id(peer,"Этот игрок уже подключён."); return
		rules.players[id].online = true
	else:
		id = _secret().substr(0,16)
		var error = rules.add_player(id,nickname)
		if not error.is_empty(): reject_join.rpc_id(peer,error); return
		token = _secret(); tokens[token] = id
	peer_sessions[peer] = id
	accept_join.rpc_id(peer,id,token)
	broadcast()

@rpc("authority", "call_remote", "reliable")
func accept_join(id: String, token: String) -> void:
	session_id = id; recovery_token = token; active = true; connecting_since = -1
	joined.emit(id,token)

@rpc("authority", "call_remote", "reliable")
func reject_join(message: String) -> void:
	_lost(message)

func _lost(message: String) -> void:
	close()
	session_closed.emit(message)

func _disconnected(peer: int) -> void:
	if rules == null or not peer_sessions.has(peer): return
	var id = peer_sessions[peer]
	peer_sessions.erase(peer)
	if rules.players.has(id): rules.players[id].online = false
	broadcast()

func send(action: String, data: Dictionary = {}) -> void:
	if not active or snapshot.is_empty(): return
	var payload = data.duplicate(true); payload.stage = snapshot.stage
	if multiplayer.is_server(): _apply(1,action,payload)
	else: submit.rpc_id(1,action,payload)

@rpc("any_peer", "call_remote", "reliable")
func submit(action: String, data: Dictionary) -> void:
	if not multiplayer.is_server() or rules == null: return
	var peer = multiplayer.get_remote_sender_id()
	if not peer_sessions.has(peer): return
	if var_to_bytes(data).size() > 8192 or action.length() > 40: return
	if now() - float(requests_at.get(peer,-1.0)) < 0.06: return
	requests_at[peer] = now()
	_apply(peer,action,data)

func _apply(peer: int, action: String, data: Dictionary) -> void:
	rules.tick(now())
	var id = peer_sessions.get(peer,"")
	var error = rules.command(id,action,data,now())
	if not error.is_empty():
		if peer == 1: error_received.emit(error)
		else: receive_error.rpc_id(peer,error)
	elif action in ["leave","kick"]:
		var target = id if action == "leave" else data.get("target","")
		for remote in peer_sessions.keys():
			if peer_sessions[remote] == target:
				receive_closed.rpc_id(remote,"Вы покинули лобби." if action == "leave" else "Создатель исключил вас из лобби.")
				peer_sessions.erase(remote)
		for token in tokens.keys():
			if tokens[token] == target: tokens.erase(token)
	broadcast()

@rpc("authority", "call_remote", "reliable")
func receive_error(message: String) -> void:
	error_received.emit(message)

@rpc("authority", "call_remote", "reliable")
func receive_closed(message: String) -> void:
	_lost(message)

func error_received_if_any(message: String) -> void:
	if not message.is_empty(): error_received.emit(message)

func broadcast() -> void:
	if rules == null: return
	serial += 1
	for peer in peer_sessions:
		var id: String = peer_sessions[peer]
		if not rules.players.has(id): continue
		var view = rules.view(id,now())
		if peer == 1: _receive(view,serial)
		else: receive_view.rpc_id(peer,view,serial)

@rpc("authority", "call_remote", "reliable")
func receive_view(view: Dictionary, sequence: int) -> void:
	_receive(view,sequence)

func _receive(view: Dictionary, sequence: int) -> void:
	if sequence <= latest_serial: return
	latest_serial = sequence; snapshot = view; clock_received = now()
	snapshot_changed.emit(view)

func remaining() -> float:
	if snapshot.is_empty() or float(snapshot.remaining) < 0: return -1
	return maxf(0,float(snapshot.remaining)-(now()-clock_received))

func _process(delta: float) -> void:
	if connecting_since >= 0 and now()-connecting_since > 12: _lost("Время подключения истекло. Проверьте адрес и UDP-порт.")
	if not active or rules == null: return
	elapsed += delta
	if elapsed >= 0.25:
		elapsed = 0
		rules.tick(now())
		broadcast()

static func audio_files(folder: String) -> Array:
	var files: Array = []
	for file in DirAccess.get_files_at(folder):
		var clean = file.trim_suffix(".remap")
		if clean.get_extension().to_lower() in ["mp3","ogg","wav"] and not files.has(clean): files.append(clean)
	files.sort()
	return files
