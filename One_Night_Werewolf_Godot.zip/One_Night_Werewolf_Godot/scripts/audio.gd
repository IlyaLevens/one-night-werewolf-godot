class_name GameAudio
extends Node
var music_player: AudioStreamPlayer
var cue_player: AudioStreamPlayer
var current_file = ""
var last_stage = ""
var music_volume = 0.35
var cue_volume = 0.5
var missing = ""

func _ready() -> void:
	music_player = AudioStreamPlayer.new(); add_child(music_player)
	cue_player = AudioStreamPlayer.new(); add_child(cue_player)

func update(view: Dictionary) -> void:
	music_player.volume_db = linear_to_db(maxf(0.0001,music_volume))
	cue_player.volume_db = linear_to_db(maxf(0.0001,cue_volume))
	if view.stage != last_stage:
		var first = last_stage.is_empty()
		last_stage = view.stage
		if view.phase == "night" and not first:
			for ext in ["ogg","wav","mp3"]:
				var path = "res://audio/roles/%s.%s" % [view.night_role,ext]
				if ResourceLoader.exists(path):
					cue_player.stream = load(path); cue_player.play(); break
	var music: Dictionary = view.music
	if music.file != current_file:
		music_player.stop(); current_file = music.file; missing = ""
		var path = "res://audio/music/" + current_file
		music_player.stream = load(path) if not current_file.is_empty() and ResourceLoader.exists(path) else null
		if not current_file.is_empty() and music_player.stream == null: missing = "Нет локального файла: " + current_file
	if music_player.stream == null: return
	var length = music_player.stream.get_length()
	var target = fmod(float(music.position),length) if length > 0 else 0.0
	if music.playing:
		if not music_player.playing: music_player.play(target)
		elif absf(music_player.get_playback_position()-target) > 1.5: music_player.seek(target)
	else: music_player.stop()
