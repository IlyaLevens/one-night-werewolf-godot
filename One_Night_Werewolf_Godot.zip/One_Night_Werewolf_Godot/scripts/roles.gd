class_name Roles
extends RefCounted

const DATA = {
  "werewolf": {
    "name": "Оборотень",
    "icon": "🐺",
    "team": "wolves",
    "limit": 2,
    "description": "Узнайте других оборотней. Если вы один, можно посмотреть одну карту центра."
  },
  "minion": {
    "name": "Приспешник",
    "icon": "🕯️",
    "team": "wolves",
    "limit": 1,
    "description": "Узнайте оборотней, но они не узнают вас. Помогите им избежать казни."
  },
  "mason": {
    "name": "Масон",
    "icon": "⚒️",
    "team": "village",
    "limit": 2,
    "description": "Узнайте второго масона. В колоду всегда добавляются оба масона."
  },
  "seer": {
    "name": "Провидица",
    "icon": "🔮",
    "team": "village",
    "limit": 1,
    "description": "Посмотрите карту одного другого игрока или две карты центра."
  },
  "robber": {
    "name": "Вор",
    "icon": "🗝️",
    "team": "village",
    "limit": 1,
    "description": "Можно обменять свою карту с другим игроком и посмотреть полученную роль."
  },
  "troublemaker": {
    "name": "Смутьян",
    "icon": "🎭",
    "team": "village",
    "limit": 1,
    "description": "Можно поменять карты двух других игроков, не подсматривая их."
  },
  "drunk": {
    "name": "Пьяница",
    "icon": "🍷",
    "team": "village",
    "limit": 1,
    "description": "Обязательно обменяйте свою карту с одной картой центра. Новую роль вы не узнаете."
  },
  "insomniac": {
    "name": "Бессонница",
    "icon": "👁️",
    "team": "village",
    "limit": 1,
    "description": "В конце ночи автоматически посмотрите свою текущую карту."
  },
  "hunter": {
    "name": "Охотник",
    "icon": "🏹",
    "team": "village",
    "limit": 1,
    "description": "Если вас казнят, игрок, против которого вы проголосовали, тоже погибнет."
  },
  "tanner": {
    "name": "Кожевник",
    "icon": "🧥",
    "team": "tanner",
    "limit": 1,
    "description": "Вы играете за себя. Побеждаете, только если погибнете в конце раунда."
  },
  "villager": {
    "name": "Мирный житель",
    "icon": "🏡",
    "team": "village",
    "limit": 3,
    "description": "Ночью вы спите. Днём сопоставляйте чужие рассказы и найдите оборотней."
  }
}

const ORDER = ["werewolf", "minion", "mason", "seer", "robber", "troublemaker", "drunk", "insomniac"]
const TEAMS = {"village":"Деревня", "wolves":"Оборотни", "tanner":"Кожевник"}
const PHASES = {"lobby":"Собираемся", "reveal":"Знакомство с ролью", "night":"Ночь", "discussion":"Обсуждение", "voting":"Голосование", "results":"Рассвет"}

static func title(role: String) -> String:
	return DATA.get(role, {}).get("name", "Неизвестно")

static func default_deck(count: int) -> Array:
	var base = ["werewolf", "werewolf", "seer", "robber", "troublemaker", "villager"]
	var extra = ["villager", "villager", "insomniac", "drunk", "hunter", "minion", "tanner"]
	return base + extra.slice(0, maxi(0, count - 3))
