class_name RoleCard
extends Button

var card_key = ""
var face = ""
var selected = false
var dead = false
var selection_number = 0
var flip: Tween
var wanted_face = ""
var font: Font

func _ready() -> void:
	custom_minimum_size = Vector2(130,164)
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	font = get_theme_default_font()
	resized.connect(func(): pivot_offset = size/2)
	pivot_offset = size/2

func set_face(value: String, animate: bool = true) -> void:
	if value == wanted_face: return
	wanted_face = value
	if flip: flip.kill()
	if not animate or not is_visible_in_tree(): face = value; scale.x = 1; queue_redraw(); return
	flip = create_tween()
	flip.tween_property(self,"scale:x",0.03,0.12)
	flip.tween_callback(func(): face = value; queue_redraw())
	flip.tween_property(self,"scale:x",1.0,0.16)

func _draw() -> void:
	if font == null: font = get_theme_default_font()
	var box = StyleBoxFlat.new()
	box.bg_color = Color("162840") if face.is_empty() else Color("ded4ba")
	box.border_color = Color("edc88d") if selected else Color("66758a")
	box.set_border_width_all(3 if selected else 1)
	box.set_corner_radius_all(12)
	draw_style_box(box,Rect2(Vector2.ZERO,size))
	if face.is_empty():
		text_center("☾",size.y*0.53,54,Color("edc88d"))
		text_center("ONE NIGHT",size.y-37,10,Color("d8c8aa"))
		text_center("WEREWOLF",size.y-21,10,Color("d8c8aa"))
	else:
		var icon = load("res://assets/icons/%s.png" % face) as Texture2D
		if icon: draw_texture_rect(icon,Rect2(Vector2(size.x/2-28,29),Vector2(56,56)),false)
		text_center(Roles.title(face),size.y-45,13,Color("202735"))
		text_center(Roles.TEAMS[Roles.DATA[face].team],size.y-23,10,Color("4b4c50"))
	if selected:
		draw_circle(Vector2(size.x-15,16),11,Color("edc88d"))
		draw_string(font,Vector2(size.x-20,21),str(selection_number),HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color("152032"))
	if dead:
		draw_line(Vector2(7,7),size-Vector2(7,7),Color("f14150"),7,true)
		draw_line(Vector2(size.x-7,7),Vector2(7,size.y-7),Color("f14150"),7,true)

func text_center(value: String, y: float, font_size: int, color: Color) -> void:
	draw_string(font,Vector2(0,y),value,HORIZONTAL_ALIGNMENT_CENTER,size.x,font_size,color)
