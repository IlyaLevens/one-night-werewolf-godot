class_name Atmosphere
extends Control

var phase = "lobby"
var motion = true
var time = 0.0
var sky = Color("473441")
var glow = Color("d7a36e")
var ground = Color("27333b")
var night_alpha = 0.0
var sun_y = 92.0
var transition: Tween
const PALETTES = {
	"lobby":["473441","d7a36e","27333b",0.0,92.0],
	"reveal":["292744","826c9b","222c3d",0.5,116.0],
	"night":["091426","405e83","101f30",1.0,170.0],
	"discussion":["546078","c29c9a","304953",0.12,104.0],
	"voting":["4a3a4d","b17c6b","30353d",0.0,85.0],
	"results":["7aa0ae","e9d9ae","3b5a55",0.0,47.0]
}

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size.y = 170

func change(next: String) -> void:
	if next == phase: return
	phase = next
	if transition: transition.kill()
	var colors = PALETTES.get(next,PALETTES.lobby)
	transition = create_tween().set_parallel(true)
	var duration = 1.8 if motion else 0.01
	transition.tween_property(self,"sky",Color(colors[0]),duration)
	transition.tween_property(self,"glow",Color(colors[1]),duration)
	transition.tween_property(self,"ground",Color(colors[2]),duration)
	transition.tween_property(self,"night_alpha",colors[3],duration)
	transition.tween_property(self,"sun_y",colors[4],duration)

func _process(delta: float) -> void:
	if motion: time += delta
	queue_redraw()

func _draw() -> void:
	var w = size.x
	var h = size.y
	for i in range(36):
		draw_rect(Rect2(0,i*h/36.0,w,h/36.0+1),sky.lerp(glow,float(i)/50.0))
	for i in range(34):
		var pos = Vector2(fmod(i*137.0+41.0,w),15+(i*31)%95)
		draw_circle(pos,1.0+float(i%2)*0.5,Color(0.85,0.94,1,night_alpha*(0.65+0.2*sin(time+i))))
	var planet = Vector2(w*0.79,lerpf(sun_y,40.0,night_alpha))
	for radius in range(65,30,-4):
		draw_circle(planet,radius,Color(0.95,0.86,0.64,0.012))
	draw_circle(planet,27,Color("ffdda0").lerp(Color("d8e9ef"),night_alpha))
	for i in range(3):
		draw_circle(planet+Vector2(-9+i*10,8-i*7),4+i,Color(0.4,0.55,0.65,night_alpha*0.25))
	for i in range(3):
		var x = w*(0.45+i*0.21)+sin(time*0.04+i)*45
		paint_ellipse(Vector2(x,60+i*21),Vector2(85,10),Color(0.8,0.86,0.9,0.08))
	var hills = PackedVector2Array([Vector2(0,h)])
	for x in range(0,int(w)+30,30): hills.append(Vector2(x,h-38-18*sin(x*0.008)))
	hills.append(Vector2(w,h)); draw_colored_polygon(hills,ground.lightened(0.12))
	for i in range(22):
		var x = float(i)*w/21
		var y = h-28+(i%3)*5
		draw_colored_polygon(PackedVector2Array([Vector2(x,y-44),Vector2(x-19,y),Vector2(x+19,y)]),ground)
	for i in range(5):
		var x = w*(0.30+i*0.13); var y = h-22-float(i%2)*8
		draw_rect(Rect2(x,y-30,43,35),ground.darkened(0.05))
		draw_colored_polygon(PackedVector2Array([Vector2(x-4,y-30),Vector2(x+21,y-50),Vector2(x+47,y-30)]),ground.darkened(0.15))
		for offset in [8,28]: draw_rect(Rect2(x+offset,y-20,7,10),Color("efc98e").lerp(ground,night_alpha*0.9))
	for i in range(10): draw_rect(Rect2(0,i*h/10.0,w*0.45,h/10.0+1),Color(0.03,0.07,0.12,0.16))

func paint_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	var points = PackedVector2Array()
	for i in range(32): points.append(center+Vector2(cos(TAU*i/32.0)*radii.x,sin(TAU*i/32.0)*radii.y))
	draw_colored_polygon(points,color)
