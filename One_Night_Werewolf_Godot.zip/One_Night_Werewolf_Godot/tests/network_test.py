"""Optional development test; Python is NOT needed to play."""
import subprocess, pathlib, time, json, sys
root = pathlib.Path(__file__).resolve().parents[1]
godot = sys.argv[1] if len(sys.argv)>1 else 'godot'
processes=[]
try:
    for i in range(3):
        command=[godot,'--headless','--path',str(root),'--','--host' if i==0 else '--join=127.0.0.1',f'--name=Bot{i}','--port=28789','--test-bot']
        processes.append(subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True))
        time.sleep(.6)
    results=[]
    for p in processes:
        output=p.communicate(timeout=35)[0]
        print(output)
        assert p.returncode==0 and 'ERROR' not in output
        rounds=[json.loads(line[len('TEST_RESULT '):]) for line in output.splitlines() if line.startswith('TEST_RESULT ')]
        assert [r['round'] for r in rounds]==[1,2]
        results.append(rounds)
    assert results[0]==results[1]==results[2], 'Clients disagree'
    print('PASS: three ENet processes, two complete rounds, identical results and scores, private snapshots')
finally:
    for p in processes:
        if p.poll() is None: p.kill()
