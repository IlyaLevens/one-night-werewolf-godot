extends Node
var elapsed = 0.0
var completed: Dictionary = {}
var stage_time = 0.0
var previous_stage = ""
func _process(delta: float) -> void:
	elapsed += delta
	if elapsed < 0.3 or Net.snapshot.is_empty(): return
	elapsed = 0
	var v = Net.snapshot
	if v.stage != previous_stage: previous_stage = v.stage; stage_time = Net.now()
	for p in v.players:
		assert(not p.has("original") and not p.has("card"),"Role leaked in public roster")
	if v.phase != "results": assert(v.result.is_empty())
	match v.phase:
		"lobby":
			if v.players.size() < 3: return
			if not v.me.ready: Net.send("ready")
			elif Net.rules != null and v.players.all(func(p): return p.ready):
				Net.rules.settings.night_seconds = 1.0; Net.send("start")
		"reveal":
			if not v.me.ready: Net.send("ready")
		"night":
			if v.me.action == "drunk": Net.send("night_action",{"mode":"center","center":[0]})
			elif not v.me.action.is_empty(): Net.send("night_action",{"mode":"skip"})
		"discussion":
			if Net.rules != null: Net.send("begin_vote")
		"voting":
			if v.me.vote.is_empty():
				var ids = v.players.map(func(p): return p.id); var target = ids[(ids.find(v.me.id)+1)%ids.size()]
				Net.send("vote",{"target":target})
		"results":
			if not completed.has(v.round):
				completed[v.round] = true
				print("TEST_RESULT "+JSON.stringify({"round":v.round,"scores":v.scoreboard,"result":v.result}))
			if Net.now()-stage_time > 1.5:
				if v.round >= 2: get_tree().quit()
				elif Net.rules != null: Net.send("reset")
