extends SceneTree
var checks = 0
func check(ok: bool, text: String) -> void:
	checks += 1
	if not ok: push_error(text); quit(1)
func setup(roles: Array, votes: Array) -> GameRules:
	var g = GameRules.new()
	for i in range(roles.size()):
		var id = str(i); g.add_player(id,"P"+id); g.players[id].card = roles[i]; g.players[id].original = roles[i]; g.players[id].vote = str(votes[i]) if votes[i] >= 0 else ""
	g.round_number = 1; g.center = ["villager","villager","villager"]
	return g
func _init() -> void:
	var g = setup(["hunter","werewolf","villager"],[1,0,0]); g.finish()
	check(g.result.players[0].executed,"Hunter executed")
	check(g.result.players[1].hunter_victim and g.result.players[1].dead,"Hunter victim marked")
	check(g.players["0"].score == 1 and g.players["2"].score == 1,"Village score")
	g.finish(); check(g.players["0"].score == 1,"No double scoring")
	g = setup(["werewolf","minion","villager"],[2,2,0]); g.finish()
	check(g.players["0"].score == 2 and g.players["1"].score == 2,"Both wolves faction +2")
	g = setup(["tanner","werewolf","villager"],[1,0,0]); g.finish()
	check(g.players["0"].score == 3 and g.players["1"].score == 0,"Tanner +3 suppress wolves")
	g = setup(["villager","seer","robber"],[1,2,0]); g.finish()
	check(g.result.players.all(func(p): return not p.dead and p.points == 1),"No wolves / no deaths")
	g = setup(["werewolf","villager","villager"],[1,2,0]); g.finish()
	check(g.players["0"].score == 2,"No execution below two votes")
	g = setup(["robber","werewolf","drunk"],[-1,-1,-1]); g.phase="night"; g.night_steps=["robber","drunk"]; g.night_index=0
	check(g.night_action("0",{"mode":"player","targets":["1"]}).is_empty(),"Robber action")
	check(g.players["0"].card=="werewolf" and g.players["1"].card=="robber","Exchange")
	check(not g.night_action("0",{"mode":"player","targets":["1"]}).is_empty(),"Reject repeated action")
	check(g.view("1",0).me.original=="werewolf" and g.view("1",0).result.is_empty(),"Private snapshot")
	g.next_night(0); g.tick(25)
	check(g.players["2"].card=="villager" and g.center.has("drunk"),"Mandatory drunk timeout")
	var before = g.players["0"].card
	check(not g.command("0","reset",{"stage":"stale"},0).is_empty(),"Stale stage rejected")
	check(g.players["0"].card == before,"Rejected command did not mutate")
	g = GameRules.new(); g.add_player("0","A"); g.add_player("1","B"); g.add_player("2","C")
	check(g.validate_deck(g.deck).is_empty(),"Default deck valid")
	check(not g.validate_deck(["werewolf","mason","seer","robber","drunk","villager"]).is_empty(),"Unpaired mason rejected")
	print("PASS: %s rule checks"%checks); quit()
