extends SceneTree
func _init() -> void:
	var cases = JSON.parse_string(FileAccess.get_file_as_string("res://tests/parity.json"))
	for fixture in cases:
		for outcome in fixture.outcomes: outcome.votes = int(outcome.votes)
		var result = GameRules.resolve(fixture.players)
		if result.teams != fixture.teams or result.players != fixture.outcomes:
			push_error("Python/Godot result mismatch"); quit(1); return
	print("PASS: 500 result fixtures agree with original Python rules"); quit()
