Add identical OGG/WAV/MP3 files on every player's computer, then import in Godot and restart the game. No tracks are bundled.
