Optional cue filenames (OGG/WAV/MP3): werewolf, minion, mason, seer, robber, troublemaker, drunk, insomniac.
All connected players hear the cue when that public night stage begins, including stages with the role only in the center.
