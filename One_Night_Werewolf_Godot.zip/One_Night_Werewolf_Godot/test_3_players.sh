#!/usr/bin/env bash
set -euo pipefail
GAME_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
GODOT_BIN="${1:-godot}"
"$GODOT_BIN" --headless --editor --path "$GAME_DIR" --import --quit
"$GODOT_BIN" --path "$GAME_DIR" -- --host --name=Host &
sleep 2
"$GODOT_BIN" --path "$GAME_DIR" -- --join=127.0.0.1 --name=Player2 &
"$GODOT_BIN" --path "$GAME_DIR" -- --join=127.0.0.1 --name=Player3 &
wait
